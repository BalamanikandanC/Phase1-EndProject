

import java.io.IOException;

import javax.persistence.NoResultException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.railwayCrossing.dao.AdminDAO;
import com.railwayCrossing.pojo.Admin;
/**
 * Servlet implementation class validateAdmin
 */
public class validateAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public validateAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			AdminDAO dao=new AdminDAO();
			Admin admin=dao.getAdmin(request.getParameter("AdminMail"));
			if(request.getParameter("AdminPassword").equals(admin.getPassword())) {
				response.sendRedirect("adminHome.jsp");
			}
			else {
				response.sendRedirect("AdminLoginFail.jsp");
			}
		}catch(NoResultException e) {
			request.setAttribute("errorMessage", "No Result Found error occured: "+e.getMessage());
			RequestDispatcher dispatcher= request.getRequestDispatcher("/AdminLoginFail.jsp");
			dispatcher.forward(request, response);
		}
	}

}
