

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.railwayCrossing.dao.FavoritesDAO;
import com.railwayCrossing.pojo.Favorites;

/**
 * Servlet implementation class addFavorites
 */
public class addFavorites extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addFavorites() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FavoritesDAO dao=new FavoritesDAO();
		Favorites fav=new Favorites();
		fav.setUserID(Integer.parseInt(request.getParameter("UserID")));
		fav.setFavoriteID(Integer.parseInt(request.getParameter("CrossingID")));
		int row=dao.addFavorites(fav);
		if(row>0) {
			if(request.getParameter("isFavPage")!=null && request.getParameter("isFavPage").equals("search")) {
				response.sendRedirect("UserSearchCrossing.jsp?id="+request.getParameter("UserID")+"&searchkey="+request.getParameter("searchkey"));
			}
			else {
			response.sendRedirect("userHome.jsp?id="+request.getParameter("UserID"));
			}
		}
	}

}
