

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.railwayCrossing.dao.UserDAO;
import com.railwayCrossing.pojo.User;

/**
 * Servlet implementation class AddNewUser
 */
public class AddNewUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddNewUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserDAO dao=new UserDAO();
		List<User> list=dao.display();
		PrintWriter pw=response.getWriter();
		RequestDispatcher dispatcher=null;
		boolean found=false;
		for(User user: list) {
			if(user.getEmail().equals(request.getParameter("UserMail"))) {
				found=true;
				break;
			}
		}
		if(found) {
			pw.print("<html><body>");
			pw.print("<div style='text-align: center'><h1>User Already Found</h1><p><i>Account with this email already exists. Please use different eamil to create an account</i><p></div>");
			pw.print("</body></html>");
			dispatcher=request.getRequestDispatcher("/RegisterUser.jsp");
			dispatcher.include(request, response);
		}
		if(!found) {
		User newUser=new User();
		newUser.setName(request.getParameter("UserName"));
		newUser.setEmail(request.getParameter("UserMail"));
		newUser.setPassword(request.getParameter("UserPassword"));
		int row=dao.addUser(newUser);
		if(row>0) {
			pw.print("<html><body>");
			pw.print("<div style='text-align: center'><h1>Account Created Successfull!!!</h1><p><i>SignIn to your Account</i><p></div>");
			pw.print("</body></html>");
			dispatcher=request.getRequestDispatcher("/UserLogin.jsp");
			dispatcher.include(request, response);
		}
		}
	}

}
