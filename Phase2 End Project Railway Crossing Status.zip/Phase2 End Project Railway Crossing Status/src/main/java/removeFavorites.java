

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.railwayCrossing.dao.FavoritesDAO;
import com.railwayCrossing.pojo.Favorites;

/**
 * Servlet implementation class removeFavorites
 */
public class removeFavorites extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public removeFavorites() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FavoritesDAO dao=new FavoritesDAO();
		Favorites fav=new Favorites();
		fav.setID(Integer.parseInt(request.getParameter("FavID")));
		dao.delete(fav);
		if(request.getParameter("isFavPage")!=null && request.getParameter("isFavPage").equals("true")) {
			response.sendRedirect("FavoriteCrossing.jsp?id="+request.getParameter("UserID"));
		}
		else if(request.getParameter("isFavPage")!=null && request.getParameter("isFavPage").equals("search")) {
			response.sendRedirect("UserSearchCrossing.jsp?id="+request.getParameter("UserID")+"&searchkey="+request.getParameter("searchkey"));
		}
		else {
		response.sendRedirect("userHome.jsp?id="+request.getParameter("UserID"));
		}
	}

}
