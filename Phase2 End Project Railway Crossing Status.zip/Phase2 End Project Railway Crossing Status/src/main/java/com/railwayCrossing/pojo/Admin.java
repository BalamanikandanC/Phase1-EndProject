package com.railwayCrossing.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Admin {
@Id
	private String AdminEmail;
	private String Password;
	public String getAdminEmail() {
		return AdminEmail;
	}
	public void setAdminEmail(String adminEmail) {
		AdminEmail = adminEmail;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
}
