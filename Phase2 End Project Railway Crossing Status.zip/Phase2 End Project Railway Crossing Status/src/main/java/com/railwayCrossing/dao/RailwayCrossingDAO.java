package com.railwayCrossing.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.railwayCrossing.dbutil.DbUtil;
import com.railwayCrossing.pojo.RailwayCrossing;

public class RailwayCrossingDAO {
	public int addCrossing(RailwayCrossing rc) {
		Session session=DbUtil.dbConn();
		Transaction trans=session.beginTransaction();
		int value=(Integer) session.save(rc);
		trans.commit();
		session.close();
		return value;
	}
	public List<RailwayCrossing> display(){
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<RailwayCrossing> query=session.createQuery("from RailwayCrossing",RailwayCrossing.class);
		List<RailwayCrossing> list=null;
		list=query.list();
		transaction.commit();
		session.close();
		return list;
	}
	public RailwayCrossing getCrossing(int id) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<RailwayCrossing> query=session.createQuery("from RailwayCrossing t where t.ID=:tid",RailwayCrossing.class);
		query.setParameter("tid", id);
		RailwayCrossing rc=query.getSingleResult();
		transaction.commit();
		session.close();
		return rc;
	}
	public void update(RailwayCrossing rc) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		session.update(rc);
		transaction.commit();
		session.close();
		return ;
	}
	public void delete(RailwayCrossing rc) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		session.delete(rc);
		transaction.commit();
		session.close();
		return ;
	}
	
}
