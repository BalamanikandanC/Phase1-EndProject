package com.railwayCrossing.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.railwayCrossing.dbutil.DbUtil;
import com.railwayCrossing.pojo.Favorites;

public class FavoritesDAO {
	public int addFavorites(Favorites favorite) {
		Session session=DbUtil.dbConn();
		Transaction trans=session.beginTransaction();
		int value=(Integer) session.save(favorite);
		trans.commit();
		session.close();
		return value;
	}
	public List<Favorites> display(){
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<Favorites> query=session.createQuery("from Favorites",Favorites.class);
		List<Favorites> list=null;
		list=query.list();
		transaction.commit();
		session.close();
		return list;
	}
	public List<Favorites> getFavoriteList(int id) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<Favorites> query=session.createQuery("from Favorites t where t.UserID=:tid",Favorites.class);
		query.setParameter("tid", id);
		List<Favorites>list=query.list();
		transaction.commit();
		session.close();
		return list;
	}
	public Favorites  getUser(int id) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		Query<Favorites> query=session.createQuery("from Favorites  t where t.ID=:uMail",Favorites.class);
		query.setParameter("uMail", id);
		Favorites user=query.getSingleResult();
		transaction.commit();
		session.close();
		return user;
	}
	public void update(Favorites  favorite) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		session.update(favorite);
		transaction.commit();
		session.close();
		return ;
	}
	public void delete(Favorites  favorite) {
		Session session=DbUtil.dbConn();
		Transaction transaction=session.beginTransaction();
		session.delete(favorite);
		transaction.commit();
		session.close();
		return ;
	}
}
