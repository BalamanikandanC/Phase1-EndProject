package com.vaccinecenter.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.vaccinecenter.pojo.Center;
import com.vaccinecenter.pojo.Citizen;
import com.vaccinecenter.service.CenterService;

@Controller
public class CenterController {

	@Autowired
	CenterService service;
	
	
	@RequestMapping("/vaccinationcenter")
	public ModelAndView vaccinationCenters(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Dashboard.jsp");
		List<Center> centers=service.getAll();
		mv.addObject("centers", centers);
		mv.addObject("user", session.getAttribute("user"));
		return mv;
	}

	@RequestMapping("/addCenter")
	public ModelAndView addCenter(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		Center center =new Center();
		center.setName(request.getParameter("name"));
		center.setCity(request.getParameter("city"));
		service.insertCenter(center);
		mv.setViewName("/vaccinationcenter");
		return mv;
	}
	
	@RequestMapping("/deleteCenter")
	public ModelAndView deleteCenter(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		service.deleteCenter(Integer.parseInt(request.getParameter("Id")));
		mv.setViewName("/vaccinationcenter");
		return mv;
	}
	
	@RequestMapping("/editCenter")
	public ModelAndView editCenter(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		Center center=new Center();
		center.setId(Integer.parseInt(request.getParameter("Id")));
		center.setName(request.getParameter("name"));
		center.setCity(request.getParameter("city"));
		service.updateCenter(center);
		mv.setViewName("/vaccinationcenter");
		return mv;
	}
	
	@RequestMapping("/vaccinationCenterAndCitizen")
	public ModelAndView CenterAndCitizen(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("CenterAndCitizen.jsp");
		Center center=service.getCenter(Integer.parseInt(request.getParameter("Id")));
		mv.addObject("center", center);
		List<Citizen>citizens=service.getCitizen(request.getParameter("name"));
		mv.addObject("citizens", citizens);
		return mv;
	}
	
}
