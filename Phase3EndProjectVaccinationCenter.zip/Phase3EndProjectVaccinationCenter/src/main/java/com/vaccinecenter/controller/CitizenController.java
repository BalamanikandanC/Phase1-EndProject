package com.vaccinecenter.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.vaccinecenter.pojo.Citizen;
import com.vaccinecenter.service.CenterService;
import com.vaccinecenter.service.CitizenService;

@RestController
public class CitizenController {

	@Autowired
	CitizenService service;
	@Autowired
	CenterService centerService;
	
	
	@RequestMapping("/citizens")
	public ModelAndView vaccinationCenters(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Citizens.jsp");
		List<Citizen> citizens=service.getAll();
		mv.addObject("citizens", citizens);
		return mv;
	}
	
	@RequestMapping("/edit")
	public ModelAndView edit(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("EditCitizen.jsp");
		Citizen citizen=service.getCitizen(Integer.parseInt(request.getParameter("Id")));
		List<String> centerNames=centerService.getAllCenterNames();
		List<String> citizenCities=service.getAllCitizenCities();
		mv.addObject("citizen", citizen);
		mv.addObject("centerNames", centerNames);
		mv.addObject("citizenCities", citizenCities);
		
		return mv;
	}
	@RequestMapping("/addCitizen")
	public ModelAndView addCitizen(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		Citizen citizen =new Citizen();
		citizen.setName(request.getParameter("name"));
		citizen.setCity(request.getParameter("city"));
		citizen.setVaccinationCenter(request.getParameter("Vcity"));
		citizen.setDose(0);
		citizen.setVaccinationStatus("Not Vaccinated");
		service.insertCitizen(citizen);
		mv.setViewName("/citizens");
		return mv;
	}
	
	@RequestMapping("/ViewCitizen")
	public ModelAndView ViewCitizen(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("ViewCitizen.jsp");
		Citizen citizen=service.getCitizen(Integer.parseInt(request.getParameter("Id")));
		mv.addObject("citizen", citizen);
		return mv;
	}
	
	@RequestMapping("/ViewCitizen/{Id}")
	public ModelAndView ViewCitizen(@PathVariable("Id") int Id) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("/ViewCitizen.jsp");
		Citizen citizen=service.getCitizen(Id);
		mv.addObject("citizen", citizen);
		return mv;
	}
	
	@RequestMapping("/deleteCitizen")
	public ModelAndView deleteCitizen(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		service.deleteCitizen(Integer.parseInt(request.getParameter("Id")));
		mv.setViewName("/citizens");
		return mv;
	}
	
	@RequestMapping("/updateCitizen")
	public ModelAndView updateCitizen(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv= new ModelAndView();
		try {
		Citizen citizen=new Citizen();
		citizen.setId(Integer.parseInt(request.getParameter("Id")));
		citizen.setName(request.getParameter("name"));
		citizen.setCity(request.getParameter("city"));
		citizen.setDose(Integer.parseInt(request.getParameter("NoOfDose")));
		String vaccinationStatus="Not Vaccinated";
		if(Integer.parseInt(request.getParameter("NoOfDose"))==1)vaccinationStatus="One Dose Vaccinated";
		else if(Integer.parseInt(request.getParameter("NoOfDose"))==2)vaccinationStatus="Fully Vaccinated";
		citizen.setVaccinationStatus(vaccinationStatus);
		citizen.setVaccinationCenter(request.getParameter("VaccinationCenter"));
		service.updateCitizen(citizen);
		mv.setViewName("/citizens");
		}catch(NumberFormatException e) {
			mv.setViewName("updateError.jsp");
		}
		return mv;
	}
}
