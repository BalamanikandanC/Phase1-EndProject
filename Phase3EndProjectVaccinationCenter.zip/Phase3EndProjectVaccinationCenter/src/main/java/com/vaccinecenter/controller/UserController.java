package com.vaccinecenter.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vaccinecenter.pojo.User;
import com.vaccinecenter.service.UserService;

@Controller
public class UserController {

	@Autowired
	UserService service;

	@RequestMapping("/login")
	public ModelAndView loginPage(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("login.jsp");
		return mv;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logoutPage(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Logout.jsp");
		return mv;
	}

	@RequestMapping("/loginAction")
	public ModelAndView loginAction(HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
		ModelAndView mv=new ModelAndView();
		List<User>userList=service.getAll();
		boolean found=false;
		User user=null;
		for(User u:userList) {
			if(u.getEmail().equals(request.getParameter("email")) && u.getPassword().equals(request.getParameter("pwd"))) {
				found=true;
				user=u;
			}
		}
		if(found) {
			HttpSession session= request.getSession();
			session.setAttribute("user", user);
			//session.setMaxInactiveInterval(30*60);
			mv.setViewName("redirect:/vaccinationcenter");
		}
		else {
			mv.setViewName("FailedLogin.jsp");
		}
		return mv;
	}

	@ResponseBody
	@RequestMapping("/registerAction")
	public String registUser(HttpServletRequest request, HttpServletResponse response) {
		if((request.getParameter("user")==null || request.getParameter("user").isEmpty() 
			|| request.getParameter("email")==null ||request.getParameter("email").isEmpty() 
			|| request.getParameter("pwd")==null || request.getParameter("pwd").isEmpty() )) {
			return "*** Provide value for all the Fields ***";
		}
		List<User>userList=service.getAll();
		boolean found=false;
		for(User u:userList) {
			if(u.getUserName().equals(request.getParameter("user")) && u.getEmail().equals(request.getParameter("email"))) {
				found=true;
			}
		}
		if(found) {
			return "*** UserName with same Email ID has already been found. ***";
		}
		else {
			User user=new User();
			user.setUserName(request.getParameter("user"));
			user.setEmail(request.getParameter("email"));
			user.setPassword(request.getParameter("pwd"));
			if(service.addNewUser(user)!=null) {
				return "*** Registration Successful!!! You can now Login ***";
			}
			else return "*** Registration Not Success ***";
		}
	}
}
