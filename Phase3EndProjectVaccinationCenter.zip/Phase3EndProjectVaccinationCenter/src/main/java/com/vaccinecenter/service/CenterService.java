package com.vaccinecenter.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vaccinecenter.pojo.Center;
import com.vaccinecenter.pojo.Citizen;
import com.vaccinecenter.repo.CenterRepository;

@Service
public class CenterService {
	
	@Autowired
	CenterRepository repo;
	
	public Center insertCenter(Center center) {
		return repo.save(center);
	}
	
	public List<Center> getAll(){
		return repo.findAll();
	}
	
	public void deleteCenter(int Id) {
		repo.deleteById(Id);
	}
	
	public void updateCenter(Center c) {
	     Center center=repo.findById(c.getId()).orElse(null);
	     center.setName(c.getName());
	     center.setCity(c.getCity());
	     repo.save(center);
	}
	
	public Center getCenter(int Id) {
		return repo.findById(Id).orElse(null);
	}
	
	public List<Citizen> getCitizen(String CenterName){
		return repo.getAllCitizen(CenterName);
	}
	
	public List<String> getAllCenterNames(){
		return repo.getAllCenterNames();
	}
}
