package com.vaccinecenter.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vaccinecenter.pojo.Center;
import com.vaccinecenter.pojo.Citizen;
import com.vaccinecenter.repo.CitizenRepository;

@Service
public class CitizenService{
	
	@Autowired
	CitizenRepository repo;
	
	public Citizen insertCitizen(Citizen citizen) {
		return repo.save(citizen);
	}
	
	public List<Citizen> getAll(){
		return repo.findAll();
	}
	
	public Citizen getCitizen(int Id) {
		return repo.findById(Id).orElse(null);
	}

	public void deleteCitizen(int Id) {
		repo.deleteById(Id);
	}
	
	public List<String> getAllCitizenCities(){
		return repo.getAllCitizenCities();
	}
	
	public void updateCitizen(Citizen c) {
		Citizen citizen=repo.findById(c.getId()).orElse(null);
		citizen.setName(c.getName());
		citizen.setCity(c.getCity());
		citizen.setDose(c.getDose());
		citizen.setVaccinationStatus(c.getVaccinationStatus());
		citizen.setVaccinationCenter(c.getVaccinationCenter());
		repo.save(citizen);
	}
}
