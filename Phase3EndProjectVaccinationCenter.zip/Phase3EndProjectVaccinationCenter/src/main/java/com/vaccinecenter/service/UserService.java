package com.vaccinecenter.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vaccinecenter.pojo.User;
import com.vaccinecenter.repo.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository repo;
	
	public User addNewUser(User user) {
		return repo.save(user);
	}
	
	public User findUser(String email){
		return repo.getUser(email);
	}
	
	public List<User> getAll(){
		return repo.findAll();
	}
}
