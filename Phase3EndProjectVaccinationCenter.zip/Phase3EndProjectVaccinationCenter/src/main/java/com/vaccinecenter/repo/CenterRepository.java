package com.vaccinecenter.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vaccinecenter.pojo.Center;
import com.vaccinecenter.pojo.Citizen;

public interface CenterRepository extends JpaRepository<Center, Integer> {

	String query="select citizen from Citizen citizen where citizen.vaccinationCenter=?1";
	@Query(query)
	public List<Citizen> getAllCitizen(String city);
	
	String query1="select distinct c.name from Center c";
	@Query(query1)
	public List<String> getAllCenterNames();
}
