package com.vaccinecenter.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vaccinecenter.pojo.Citizen;

public interface CitizenRepository extends JpaRepository<Citizen, Integer>{

	String query="select distinct c.city from Citizen c";
	@Query(query)
	public List<String> getAllCitizenCities();
}
