package com.vaccinecenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase3EndProjectVaccinationCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase3EndProjectVaccinationCenterApplication.class, args);
	}

}
